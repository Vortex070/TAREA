#pragma once
#include "ofMain.h"
class PutPixel {
public:

	void clear(const ofColor& color);

	void update();
	void draw();

	void putpixel(const int& x, const int& y, const ofColor& color);

	

//private:
	ofImage _img;
	void FASTputpixel(const int& x, const int& y, const ofColor& color);

};