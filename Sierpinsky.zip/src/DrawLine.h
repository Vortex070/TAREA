#pragma once
#include "PutPixel.h"
class DrawLine {
public:

	PutPixel pixel;
	
	void NewClear();

	void midLine(int x0, int y0, int x1, int y1);

};